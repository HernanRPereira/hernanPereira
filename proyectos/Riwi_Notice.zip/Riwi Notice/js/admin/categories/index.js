import { post } from "../../api/clientHttp.js";
import { URL_CATEGORIES } from "../../api/URLS.js";
//Selectores
const formCategories = document.getElementById("formCategories");
const nameCategory = document.getElementById("nameCategory");
const descriptionCategory = document.getElementById("descriptionCategory");

formCategories.addEventListener("submit", (event) => {
  event.preventDefault();

  createCategory();
});

document.addEventListener("DOMContentLoaded", () => {
  getCategories();
});
async function createCategory() {
  const newCategory = {
    name: nameCategory.value,
    description: descriptionCategory.value,
  };

  await post(URL_CATEGORIES, newCategory);
}

async function getCategories() {
  const data = await get(URL_CATEGORIES);
  console.log(data);
}
