export async function post(url, info) {
  try {
    const reponse = await fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(info),
    });

    const data = await reponse.json();
    return data;
  } catch (error) {
    console.error(error);
  }
}

export async function get(url){
    try{
        const reponse = await fetch(url);
        const data = await reponse.JSON();

        return data;
    } catch(error){
        console.error(error);
    }
}
