export const URL_BASE = "http://localhost:3000";
export const URL_NEWS = `${URL_BASE}/news`;
export const URL_CATEGORIES = `${URL_BASE}/categories`;
export const URL_USERS = `${URL_BASE}/users`;