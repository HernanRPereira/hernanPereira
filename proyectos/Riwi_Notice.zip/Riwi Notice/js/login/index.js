import {URL_USERS} from "../api/URLS.js";
//Selectores: 

const formLogin = document.getElementById("formLogin");
const email = document.getElementById("email");
const password = document.getElementById("password");

//Eventos: 

formLogin.addEventListener("submit", (event)=>{
  event.preventDefault();

  logIn();
});
//Peticion HTTP:
async function logIn(){
  const response = await fetch(`${URL_USERS}?email=${email.value}`);
  const data = await response.json();

  if (!data) {
    console.error("Error no Registra");
    return;
  } 

  if (data[0].password !== password.value){
    console.error("Contraseña Incorrecta");
    return;
  }

  localStorage.setItem("user", JSON.stringify(data[0]));
  window.location.href = "administrator.html";
}
